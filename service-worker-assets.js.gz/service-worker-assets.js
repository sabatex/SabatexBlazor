self.assetsManifest = {
  "version": "djEzzhOW",
  "assets": [
    {
      "hash": "sha256-Puw1NCI8GBOoTg9dMeolJqdX2gvJRy0xwxT91YV8Q9Q=",
      "url": "Sabatex.RadzenBlazor.Demo.styles.css"
    },
    {
      "hash": "sha256-46vm6VbMgu3sc42FwTpkQwTjme+Po77GtioZK6YVlSk=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-ZwfLTBSCfMVDl+CeYuZ7AZl6QOeWtiEDsMNH1s/Ixdw=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-GULhKD5PINDJd/OPX3yj8H303KGZXJBBb783jLCKgSo=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-oUqzDxYNe80U+p/qGo910JR5uFQIteOxLz1nRjlOAi0=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-veyUOeT5TxeUOUlI06w8gHeU6191B4Quv2wJnT1fKPA=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-Zs32I5vhzuKRXRr4yPLVmNqHMe8Puc/z0m88G6d9ra8=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-lYiMLG73UrqjeD3Xr0zwkygnPDSAQXeAo1554Yjqjkc=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-Zau8BejdxX6Aig0Bc/WovOamuonDtmg/WW+Y1aIkSuU=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-R2NA/p3Oqmezpj6sYTnspXJtDkPjveYt8y/Jc+ODNmg=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-QYflUVxBgLxR3DE7itR92NMrE/rP5QyK8gKa/R/lgNs=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-+PA/TMpN+uUgTwqwLmA/nfoyXy9AzOtxFRb9Ejy0j6k=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-sTk3OMfTvdbGaRfKOF4i+vk1tO5OaXA9NuyvccCCQDk=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-J8kJYxpBFMrMjHMBSdDlq1lYqyntxOrDZ8AW5FrxH8U=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-/XhAh5uwu9jLLftE0d0uQBhdtFMsIlOC17sqbXYURo4=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-f0TQiqIBNg73f5XBY+9FGeLwoMzclRjJzXQp3gMgqMA=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-ijDwWRMxGG7/80sB6BInfdABDQWePHnCA+HTL8fcA04=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-mscmBJFsTrAe0H/SoknylPnukiQX2yfQ/zSnbR4B75k=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-GvevBHkQdgZjwifO4s/SmWJRh3ZjQRoOBfNIDI2oh1U=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-y6x9nQqkv3mW+Dvmm6Pvh+h0ixHfY0RLzrX6ZlktoG4=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-zy1lENb9R7JlwZYjnnGHvLdfzp6kwHpd+MPfJj8bfGo=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-fzXK/2BQ8C/lABKJC6dsV+cXmFHprEg2ICoPIqt6r2E=",
      "url": "_content/Radzen.Blazor/css/math.css"
    },
    {
      "hash": "sha256-2S1C0w/NDCDKePujIyqr2e9QV9KkU/vC80d+RWYe080=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-g40MMhZnQusZtaiivDdp3hql3/KwZhLhrreoK2saRYQ=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-mHh6OGo9cpMZlZptx+gUmbVAY28oSpRtDR7lsb98WKk=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-elAwYTeIFPifUlqcJr6Ci4MhCJyzJrVK793EdpgCsfI=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-tRcVAq9DGc0nyvTuxUpiBTY8PaxnC6deHLSE8Ri1PMg=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-kD4T9W2wg/80SzAeobJp47zpnik/vqb4RNTljHyftNs=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-MDw8asWAwuNV1RDmFK7GEAf5nyxeK6SCMFng10R3GMs=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-w+u5dJ/mdzBhZEhwULqfrrJuBuRCiLXeLLKqRQ3QA6Y=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-HYNTnwNf3xj899KPdiKwmD1e5t3XRg9VaQgB1ZOvKeI=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-WFJ1U8nTZcDc4+Y11+tGTXIaJirBYauRpgm1YDC6FRk=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GFU2mt0A9T8j9YMwMQqIUmdziKNDuPppDCn2o37LV2E=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-sHZWuJsAJXLz696mlvnAKHKfbGn7ivEi1ehiEFwtSIY=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-+eSpwuS0Mx0DVjyuFo3DoQXiI+Mp+4I1MtdWSbDcZK4=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-Tl+shwiDeqhNaIlhejaYLDFgyv9Sbxmz9mU0igt23Mw=",
      "url": "_content/Sabatex.RadzenBlazor/Sabatex.RadzenBlazor.27lc9oar2h.bundle.scp.css"
    },
    {
      "hash": "sha256-D/9Jq6l750b58m1T393jU4TGTaho3mm8bMsO4AQ+Z/U=",
      "url": "_content/Sabatex.RadzenBlazor/Sabatex.RadzenBlazor.js"
    },
    {
      "hash": "sha256-wxgOEutoVESrQREChQ/xGo2/MOVzNI4K2Kgs77SRMvE=",
      "url": "_content/Sabatex.RadzenBlazor/qrcode.js"
    },
    {
      "hash": "sha256-xUHvBjJ4hahBW8qN9gceFBibSFUzbe9PNttUvehITzY=",
      "url": "_content/Sabatex.RadzenBlazor/qrcode.min.js"
    },
    {
      "hash": "sha256-zQzieAJzoElZ0g/uVpGwfRcQs/rWjAvBweNn8AEgH9c=",
      "url": "_content/Sabatex.RadzenBlazor/radzen_ssr_layout.css"
    },
    {
      "hash": "sha256-6jvl7XruB4CBNv6dqYVoKQ0o+F0ih8mz2mtI2eQISiU=",
      "url": "_content/Sabatex.RadzenBlazor/radzen_ssr_layout.js"
    },
    {
      "hash": "sha256-hyj+5aHc/Z0gokcosJ8D9/8TtYpRRyZJHI9CDtuo4kw=",
      "url": "_framework/Markdig.b3xwtrjo89.wasm"
    },
    {
      "hash": "sha256-TuHj5ssFCLndEvqfyOU/Fhc1wlXUccTZH7vp0vLJOJQ=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.2w73kwsssx.wasm"
    },
    {
      "hash": "sha256-DYqteYyOgNgp2GTyjPOMuTfYSKm/t8XnT/ikk2qMlbk=",
      "url": "_framework/Microsoft.AspNetCore.Components.5quia5yi6x.wasm"
    },
    {
      "hash": "sha256-eX9epkQSB1HUvfecxf66uG109w5lNKBqWzaN70Rf39c=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.7cleppani7.wasm"
    },
    {
      "hash": "sha256-MZZTpP2g9lt3OcfLxg1njwUrYdFpdiftU6DWllfokjI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.10rq3ezq5u.wasm"
    },
    {
      "hash": "sha256-7JP/9EI7Uia5WylVUEOHZaj6BKRI6DpjP7djY+tgfwA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.0twowc2nte.wasm"
    },
    {
      "hash": "sha256-kT4nJ4FzCv8y+W6On7sCtiUy2xhdGUe1sw3FgbJmRPg=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.d5dcth9zwy.wasm"
    },
    {
      "hash": "sha256-OD7cjWUJ209opH9IGzfiwAAFM0G3SeYv5KeSwjLl9aI=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.gmpisozv5d.wasm"
    },
    {
      "hash": "sha256-c4VNnxCS/7i4eyB1cTZrH0JKAjCUz5jWo8DvxcYOH2o=",
      "url": "_framework/Microsoft.CSharp.ppzrxrw6a0.wasm"
    },
    {
      "hash": "sha256-3ADlF4CLU1Q+dQbj0MnPVnEJPiA4q4Jv5xxmiGEvBks=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.85u9862gz3.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-fN4AyqImDQ+h3H7tFeF4ZSkjIHJ7qWgbKL217x6P53s=",
      "url": "_framework/Microsoft.Extensions.Configuration.cyz6aj3end.wasm"
    },
    {
      "hash": "sha256-t3CE47vYQ6zRC/gv2pVAqA2Z8M53ftN8+KeCz3xos5M=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.51et7j9yx7.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-COGIH7l+iLC9osGHV6joSp9WaHN5iNXMcQourYY4XjY=",
      "url": "_framework/Microsoft.Extensions.Localization.4d6r2tb18w.wasm"
    },
    {
      "hash": "sha256-gAssamQIbTevquBNPj9X6SDMBpEomnx67DiY6WwG0Jg=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.omh1hdyz67.wasm"
    },
    {
      "hash": "sha256-a46hXU/pDe/suWrF3e8v5rxhPnX/mO1WHeJG/vOT460=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.9nlsprpemd.wasm"
    },
    {
      "hash": "sha256-I/euMiwOKn2U2Y1vqcUjYWEG/7zWmvDiTlHAoPLRHQ0=",
      "url": "_framework/Microsoft.Extensions.Logging.p9svcbtg1a.wasm"
    },
    {
      "hash": "sha256-ZhMP66Xdwsxg3woDGMbE/PrgYbF1Ok/Fju/43KlNEtI=",
      "url": "_framework/Microsoft.Extensions.Options.684cvt6ofy.wasm"
    },
    {
      "hash": "sha256-WXYpl64HUqc9+prJOz6dOEVvB8PFJhTdfqUMB3ZGRGA=",
      "url": "_framework/Microsoft.Extensions.Primitives.5pxr7nzxwe.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-/1ZLYN7kGbiaf5A1mRrzPPLlkM3ztDqm+RYpw/p9ceY=",
      "url": "_framework/Microsoft.JSInterop.thg64f7yod.wasm"
    },
    {
      "hash": "sha256-d16U1yI8YpNiSO10W4XzZOv37r/A8dJbvt9/04LPsU4=",
      "url": "_framework/Radzen.Blazor.b38uiux5qw.wasm"
    },
    {
      "hash": "sha256-0U3HGJH3R+Y19oJiB9q6NapcyJGSGW/0XBEgAiSp4LA=",
      "url": "_framework/Sabatex.Core.pibqlzjns5.wasm"
    },
    {
      "hash": "sha256-3I7xW1kaywnXhqbVFXFGKYtfFlWPN8vpQH/Tpambg+0=",
      "url": "_framework/Sabatex.RadzenBlazor.4cz5b5x4py.wasm"
    },
    {
      "hash": "sha256-YQd4FXuzNPfoZ7hImNEbQAplz+w5WM3/gW/na982H2U=",
      "url": "_framework/Sabatex.RadzenBlazor.Demo.fsm13fl06a.wasm"
    },
    {
      "hash": "sha256-WY7oA0yARcNn8NhdsE1+wysftfVMV/5ChW2ri6eSj28=",
      "url": "_framework/System.Collections.Concurrent.5dg27qw3mn.wasm"
    },
    {
      "hash": "sha256-x7kpK7vvIiK8Oy5w0k7nFoq44KqJdbFzAFEVKjQBK6o=",
      "url": "_framework/System.Collections.Immutable.9wjem99jup.wasm"
    },
    {
      "hash": "sha256-QebNkQryDxN25Q7cvUuwOCtyqNGH+4wwZCepYSOGAFs=",
      "url": "_framework/System.Collections.NonGeneric.5fqaa2ju7o.wasm"
    },
    {
      "hash": "sha256-I7h/7ddX61kZM04cR3y32oSterzKgBc9x9lHJZLH7D0=",
      "url": "_framework/System.Collections.Specialized.j4cbilqd6x.wasm"
    },
    {
      "hash": "sha256-QFXjPRd3tgBT5grro88vnTJk9JMYmfKhfRgnDcmoZAU=",
      "url": "_framework/System.Collections.gg3rr0tt2e.wasm"
    },
    {
      "hash": "sha256-/TUgJRG3EZB5Bcfo9BEFJ61DIJLAJRTXeLYB1vnMd1Q=",
      "url": "_framework/System.ComponentModel.5y3o4qq5pj.wasm"
    },
    {
      "hash": "sha256-EVylM3ytQByZ//AbNeIvWvMdttHN5vp+LWvP6PNZTkM=",
      "url": "_framework/System.ComponentModel.Annotations.jj302cyugb.wasm"
    },
    {
      "hash": "sha256-XdzW1zcnBiW+VvNa7kSiXfzJ2IvaX6ueh3A3T7EES10=",
      "url": "_framework/System.ComponentModel.Primitives.ruhptkfg11.wasm"
    },
    {
      "hash": "sha256-USzpYt5sZ3VQNTKikqpGFx0rrFGBDn5U8inlT/4vQg0=",
      "url": "_framework/System.ComponentModel.TypeConverter.9y8o9sxxc1.wasm"
    },
    {
      "hash": "sha256-XGyj6mJKAibaka1K6PF2ZMsU0Tptsee9wMwP4/HBx+E=",
      "url": "_framework/System.Console.cem5zkkqfp.wasm"
    },
    {
      "hash": "sha256-kh4hWB30Fm3u3oP8n59f5LFE0lS6vqtyU8IQzKs5oO8=",
      "url": "_framework/System.Core.mi5id249j0.wasm"
    },
    {
      "hash": "sha256-atswtAASP4K/V/BrJirrNYAvmzDJrE+b/Nzd48w/BSA=",
      "url": "_framework/System.Data.Common.umeq0mk01d.wasm"
    },
    {
      "hash": "sha256-gyDSa5r5b9+T3/LLN701Ns2ydjSZDu9XPBN7yc5DB8I=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.tge9i76ciu.wasm"
    },
    {
      "hash": "sha256-loiXSFF1+Zo5TBlJtfBil42YyTPVd8LYEkutf9ZnakE=",
      "url": "_framework/System.Drawing.Primitives.ipk39d478j.wasm"
    },
    {
      "hash": "sha256-oiiMus6vWgrlohxq9qh1XosItYfnyEecLBjVPRvbLHI=",
      "url": "_framework/System.Drawing.ewphiunpcg.wasm"
    },
    {
      "hash": "sha256-tCvlwGJAx3TJMot5V3EE7CsL75IH2QH821792tEpUhM=",
      "url": "_framework/System.IO.Pipelines.kapd30rafw.wasm"
    },
    {
      "hash": "sha256-StyLrlZLUXVjWWtxe2QtDoA21iFrVqzkGh/WnChPFv4=",
      "url": "_framework/System.Linq.Expressions.i6ipon6ekq.wasm"
    },
    {
      "hash": "sha256-HBaxWdFKhpBg2RkUIRc8W4B/nr4Mwb6uHmO0OsqspzI=",
      "url": "_framework/System.Linq.Queryable.468fbptu2s.wasm"
    },
    {
      "hash": "sha256-HklIWI7wpyuArCDx2UWul0mcZvaqeiA2ywqYR/eWhMQ=",
      "url": "_framework/System.Linq.e5etqgbedh.wasm"
    },
    {
      "hash": "sha256-P1sR18gJFiZR099QPZ+/NJvf/NBv202v7FhVSJSIPlg=",
      "url": "_framework/System.Memory.7yrz34v2p6.wasm"
    },
    {
      "hash": "sha256-WWgclmnD7k3WhI7aFg88xggBh802G/3Q4g92HKDWuyc=",
      "url": "_framework/System.Net.Http.Json.jlunhvlrcf.wasm"
    },
    {
      "hash": "sha256-kx9zdIvOj9lYEtIL2NzP7ZoRtPR+DTySXRH83RAJ4nI=",
      "url": "_framework/System.Net.Http.bmbze38ra4.wasm"
    },
    {
      "hash": "sha256-rGIYM/g7mFHB4tUKXxzKAMTdeOGYJ8NmnYQ66r9vFwE=",
      "url": "_framework/System.Net.Primitives.0h7y3g6nqf.wasm"
    },
    {
      "hash": "sha256-ykJ1xusIsrZzLFIdCA1xUAirElXE8djMb4N/UeYz0OQ=",
      "url": "_framework/System.ObjectModel.e7c0pzin5h.wasm"
    },
    {
      "hash": "sha256-1Z95b+boxzL1bWbeeZE9x3syWtM/hD57shC5d6W9XJE=",
      "url": "_framework/System.Private.CoreLib.7thgaei5vg.wasm"
    },
    {
      "hash": "sha256-WT+RxyUm+UaGGV9O6OgTXGZrcFPNTy0OvP+V8xI1O7A=",
      "url": "_framework/System.Private.Uri.3thymb5wer.wasm"
    },
    {
      "hash": "sha256-RPPMxOp8NXB3Mpw4g7uAtBkTpUhh99GWC/1vwBXtn1Q=",
      "url": "_framework/System.Private.Xml.Linq.ojoky2x6ju.wasm"
    },
    {
      "hash": "sha256-lvaRjLwwH+3BnmBBtAq/UX8WlWOI5gaSu1eQWHksIJg=",
      "url": "_framework/System.Private.Xml.i2hk6gn8z7.wasm"
    },
    {
      "hash": "sha256-Rwrv2JGR2BXnB0UEeAnykKPE+DWRlxiEPQvnYNGkheo=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.xydwfugpt6.wasm"
    },
    {
      "hash": "sha256-llO4bpLg0jQSZzTSkTE8JMMtAFEVqHXVulPeY3CJ6zE=",
      "url": "_framework/System.Reflection.Emit.moyk3dnjd3.wasm"
    },
    {
      "hash": "sha256-1PpEowNT285pH9QLabbBJhUwVk5N8pShAHK7R24yP/c=",
      "url": "_framework/System.Reflection.Primitives.s2j1s28uhr.wasm"
    },
    {
      "hash": "sha256-5X6FWiZE4NSx4s9iNjfVim2lWQpcbVIsorx1vB6lyno=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f7txb1es0b.wasm"
    },
    {
      "hash": "sha256-LfM6BypmGux3PI4QlIFNgVImNiJP2cT2bRxIdmr+NEc=",
      "url": "_framework/System.Runtime.InteropServices.t4gipi9sfm.wasm"
    },
    {
      "hash": "sha256-v5VUTg84n8lTiYdSZXSYXy9m0WC2k99Ij2F6RCjblTc=",
      "url": "_framework/System.Runtime.Serialization.Primitives.b9zxhpbsq0.wasm"
    },
    {
      "hash": "sha256-Ks/8eZXNJf6K0+Q8sgQpXGfr5fvIIvvKGZSaV0xiWn0=",
      "url": "_framework/System.Runtime.ih608ud8l3.wasm"
    },
    {
      "hash": "sha256-mRZ0N7ugfut+CkSG7lEUFEn2nS9GNoziPpSv8Z2Zoec=",
      "url": "_framework/System.Security.Claims.16kquojzwc.wasm"
    },
    {
      "hash": "sha256-BkAo1wUO1j2o4gAgHdIcf5krMaKLY2JTATftC8u/rHw=",
      "url": "_framework/System.Text.Encodings.Web.ujbee8yy9l.wasm"
    },
    {
      "hash": "sha256-EBqbyPy792UoJiV1GvpsPqCKutKzzJHl55/aiIc6QvI=",
      "url": "_framework/System.Text.Json.0gd4x3lk18.wasm"
    },
    {
      "hash": "sha256-B64adZoDNqoYcIavZF7NZcfAiYHz5dYtHbpFibRUl68=",
      "url": "_framework/System.Text.RegularExpressions.3trtodlfqy.wasm"
    },
    {
      "hash": "sha256-C/AUG9JZAC5iks6D3bDfW96IeOqOyh+0V7svrdir2HA=",
      "url": "_framework/System.Threading.ff2vmnk05t.wasm"
    },
    {
      "hash": "sha256-0OnLnH9EvbzQVEDezQQPsV1xdkAOloFM0xMuE2gnyDc=",
      "url": "_framework/System.Web.HttpUtility.wsed2e1pbx.wasm"
    },
    {
      "hash": "sha256-yo+J3RWIIHIiwAhqsR9JizNkH/+hd3auB44RBmvvLoI=",
      "url": "_framework/System.Xml.Linq.qsgzs1hc1j.wasm"
    },
    {
      "hash": "sha256-sUpLFuNZQPCWGlQhhlmQjvC+8foGtglJhLTZ0lvunDY=",
      "url": "_framework/System.Xml.XDocument.bh6q24w1sa.wasm"
    },
    {
      "hash": "sha256-hkGLo/MuT/FJ0Xf4XUL0D2VA4dZV532GHNB1JicxLko=",
      "url": "_framework/System.m0fu6d0eya.wasm"
    },
    {
      "hash": "sha256-YUm5eaD6DR9YTQsqDTiFwfkHiqq0TNkd2GjctlHPwFc=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-RtuwNrUOdAJ5A4aS4ZmceO4ySriaYqTdC7X++6yd9lM=",
      "url": "_framework/dotnet.native.21mns4qp4i.wasm"
    },
    {
      "hash": "sha256-oS7IRiQoVt9ThQ7Y2UM3XoeY0JqPD02cg9IvRdufn2w=",
      "url": "_framework/dotnet.native.9ih887ebfz.js"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-HWo/GizJUcIcWIXvGJd48c73IjNjPAq0DTAarRHIRB8=",
      "url": "_framework/uk/Sabatex.Core.resources.1bxy918b0o.wasm"
    },
    {
      "hash": "sha256-UGu1dG1mVdEQMWmwIepdijsQK0LH45nuGucQKYuauaI=",
      "url": "_framework/uk/Sabatex.RadzenBlazor.resources.oahzp4muaw.wasm"
    },
    {
      "hash": "sha256-J1DAQB77DbQHpiVtxUWNk01aoF4nWtu1DbPo99KOhTY=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-kWn8UcinUtrIHPa8OwdlRUdmEKrp6GKSDapZOfJi1BQ=",
      "url": "docs/GetStarted.md"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-AW0QPWN4Doa0HSZSgO85ABhWEPUqi2GlAqZdaySx3dE=",
      "url": "index.html"
    },
    {
      "hash": "sha256-GzUsrOTNIunyPWpHRiyzZwnsuLxVWhDDK9MRcDLko2I=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
